#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SillyTavern 预设体检工具
用法:
    python3 audit_preset.py <preset.json>          # 体检报告
    python3 audit_preset.py <preset.json> --render # 附带完整宏展开渲染
退出码: 0=无严重问题, 1=存在严重问题(❌), 2=不是预设文件
"""
import json
import re
import sys
import argparse

CRITICAL = '❌'
WARN = '⚠️'
OK = '✓'
NO_COLOR = False


def sym(s):
    return s


def c(tag, text):
    if NO_COLOR:
        return text
    colors = {'r': '\033[91m', 'y': '\033[93m', 'g': '\033[92m', 'b': '\033[96m', 'd': '\033[2m'}
    return f"{colors.get(tag, '')}{text}\033[0m"


def load(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


# ---------------------------------------------------------------- 宏展开引擎
class MacroEngine:
    """按酒馆语义从左到右展开宏（审计用的确定性模拟）"""

    def __init__(self):
        self.vars = {}
        self.unresolved = []  # 未识别的宏（运行时宏如 user/char）

    def expand(self, text, depth=0):
        if depth > 8:
            return text
        out, i, n = [], 0, len(text)
        while i < n:
            if text[i] != '{' or not text.startswith('{{', i):
                out.append(text[i]); i += 1; continue
            # 值允许内嵌一层完整宏（如 {{user}}），到非宏内的 }} 为止——与酒馆"先解析内层宏"的语义一致
            m = re.match(r'\{\{(setvar|addvar)::([^:}]+)::((?:(?!\{\{|\}\})[\s\S]|\{\{[^{}]*\}\})*)\}\}', text[i:])
            if m:
                if m.group(1) == 'setvar':
                    self.vars[m.group(2)] = m.group(3)
                else:  # addvar（值为空时等于初始化）
                    self.vars[m.group(2)] = self.vars.get(m.group(2), '') + m.group(3)
                i += m.end(); continue
            m = re.match(r'\{\{getvar::([^:}]+)(?:::([^}]*))?\}\}', text[i:])
            if m:
                val = self.vars.get(m.group(1), m.group(2) if m.lastindex >= 2 else '')
                out.append(self.expand(val, depth + 1))
                i += m.end(); continue
            m = re.match(r'\{\{random::([^}]*)\}\}', text[i:])
            if m:
                opts = m.group(1).split('::')
                out.append(opts[0] if opts else '')  # 确定性取第一项
                i += m.end(); continue
            if re.match(r'\{\{trim\}\}', text[i:]):
                i += len('{{trim}}'); continue
            m = re.match(r'\{\{//[\s\S]*?\}\}', text[i:])
            if m:  # 注释宏
                i += m.end(); continue
            m = re.match(r'\{\{[a-zA-Z_][^}]*\}\}', text[i:])
            if m:  # 运行时宏（user/char/lastUserMessage 等）原样保留
                self.unresolved.append(m.group(0))
                out.append(m.group(0)); i += m.end(); continue
            out.append(text[i]); i += 1
        return ''.join(out)


# ---------------------------------------------------------------- 检查项
def get_flow(data):
    prompts = {p['identifier']: p for p in data.get('prompts', [])}
    order = []
    for po in data.get('prompt_order', []):
        order.extend(po.get('order', []))
    return prompts, order


def check_order_table(prompts, order, problems):
    print(c('b', '\n━━━ 1. 条目顺序表（发送顺序） ━━━'))
    seen = set()
    for i, o in enumerate(order):
        ident = o['identifier']
        p = prompts.get(ident)
        if p is None:
            problems.append(f'❌ order 引用了不存在的条目: {ident}')
            print(f'{i:3d}. {sym(CRITICAL)} [缺失] {ident}')
            continue
        seen.add(ident)
        role = p.get('role', 'system')
        pos = p.get('injection_position', 0)
        depth = p.get('injection_depth', 4)
        ln = len(p.get('content', '') or '')
        flags = []
        if p.get('marker'):
            flags.append('MARKER')
        if pos == 1:
            flags.append(f'INJ@{depth}')
        en = 'ON ' if o.get('enabled') else 'off'
        print(f'{i:3d}. [{en}] {p.get("name","")!r:40s} role={role:9s} len={ln:5d} {" ".join(flags)}')
    missing = set(prompts) - seen
    if missing:
        for m in missing:
            problems.append(f'⚠️ 条目未出现在 order 中(不会被发送，可能为留档): {prompts[m].get("name")} ({m})')
    return seen


def check_vars(prompts, order, problems):
    print(c('b', '\n━━━ 2. 变量链审计 ━━━'))
    sets, adds, gets = {}, {}, {}
    for i, o in enumerate(order):
        p = prompts.get(o['identifier'])
        if not p:
            continue
        ct = p.get('content', '') or ''
        for m in re.finditer(r'\{\{setvar::([^:}]+)::((?:(?!\{\{|\}\})[\s\S]|\{\{[^{}]*\}\})*)\}\}', ct):
            sets.setdefault(m.group(1), []).append((i, m.group(2)))
        for m in re.finditer(r'\{\{addvar::([^:}]+)::', ct):
            adds.setdefault(m.group(1), []).append(i)
        for m in re.finditer(r'\{\{getvar::([^:}]+?)(?:::[^}]*)?\}\}', ct):
            gets.setdefault(m.group(1), []).append(i)

    allvars = sorted(set(sets) | set(adds) | set(gets))
    if not allvars:
        print(f'{sym(OK)} 无变量')
        return
    for v in allvars:
        s_loc = sets.get(v, [])
        a_loc = adds.get(v, [])
        g_loc = gets.get(v, [])
        producers = [(i, val) for i, val in s_loc if val and val.strip()] + [(i, True) for i in a_loc]
        inits = [i for i, val in s_loc if not (val and val.strip())]
        # 变量典型值长度（用于区分"内容块"与"参数引用"）
        val_len = max([len(val) for _, val in s_loc] + [1])
        note = []
        # 死变量：有生产者但从未 get
        if producers and not g_loc:
            problems.append(f'❌ 死变量 {v}: set/add 于 {[i for i,_ in producers]} 但从未 getvar，AI 读不到')
            note.append(sym(CRITICAL) + ' 死变量')
        # 幽灵变量：被 get 但全文件从未 set（渲染为空，常见于宏被意外转义损坏或版本迭代遗留）
        if g_loc and not s_loc and not a_loc:
            problems.append(f'⚠️ 幽灵变量 {v}: 在 {g_loc} 处 getvar，但任何条目都从未 setvar，渲染永远为空')
            note.append(sym(WARN) + ' 幽灵变量(只get无set)')
        # 重复：区分两种形态——
        #  a) 条目内 set+get 就地显示，别处又 get → 真重复（大概率失误）
        #  b) 生产条目纯 setvar，多个汇总点装配 → 可能是故意的分层强调（如头部+尾部双保险）
        inline_get = [i for i in g_loc if i in [x for x, _ in producers]]
        remote_get = [i for i in g_loc if i not in [x for x, _ in producers]]
        if inline_get and remote_get and val_len > 80:
            problems.append(f'❌ 重复输出 {v}: 条目内 set+get 就地显示，且 {remote_get} 处又 get，内容双倍发送')
            note.append(sym(CRITICAL) + ' 重复输出')
        elif len(g_loc) > 1 and val_len > 80:
            note.append(f'{sym(WARN)} 多点装配({g_loc}，确认是否有意分层强调)')
        elif len(g_loc) > 1:
            note.append(f'{sym(OK)} 多处引用(短参数值)')
        # addvar 无前置 setvar
        first_set = min([i for i, _ in s_loc], default=99_999)
        if a_loc and min(a_loc) < first_set:
            problems.append(f'⚠️ addvar 变量 {v} 在首次 setvar(条目{first_set}) 之前 add（条目{min(a_loc)}），不生效')
            note.append(sym(WARN) + ' add先于set')
        # 仅初始化从未生产
        if inits and not producers:
            note.append(sym(WARN) + ' 仅清零无生产(可清理)')
        if not note:
            note = [sym(OK)]
        print(f'  {v:24s} 初始化@{inits} 生产@{[i for i,_ in producers]} 消费@{g_loc}  {" ".join(note)}')


def check_structure(prompts, order, problems, data):
    print(c('b', '\n━━━ 3. 结构检查 ━━━'))
    enabled = [(o, prompts[o['identifier']]) for o in order
               if o.get('enabled') and o['identifier'] in prompts
               and not prompts[o['identifier']].get('marker')
               and prompts[o['identifier']].get('injection_position', 0) != 1]
    # 空内容条目运行时通常被丢弃，判断末位时跳过
    meaningful = [(o, p) for o, p in enabled if (p.get('content', '') or '').strip()]

    # 3.1 末位 assistant 预填
    roles = [p.get('role') for _, p in meaningful]
    last_p = meaningful[-1][1] if meaningful else None

    def is_prefill_style(p):
        """以未闭合开标签结尾的 assistant 条目 = 预填型卡cot（区别于顶部破限回信）"""
        return bool(re.search(r'<[a-zA-Z_][\w~－-]*>\s*$', (p.get('content', '') or '').rstrip()))

    if last_p is not None and roles[-1] == 'assistant':
        print(f'  {sym(OK)} 末条为 assistant 预填（卡cot位置正确）')
    elif last_p is not None and roles[-1] == 'user' and re.search(
            r'"role"\s*:\s*"assistant"', last_p.get('content', '') or ''):
        print(f'  {sym(OK)} 末条为 user 伪造 assistant 对话（Claude 式卡cot变体）')
    elif any(r == 'assistant' and is_prefill_style(p) for r, (_, p) in zip(roles, meaningful)):
        bad = next(p for r, (_, p) in zip(roles, meaningful)
                   if r == 'assistant' and is_prefill_style(p))
        problems.append(f'❌ 预填型 assistant 条目({bad.get("name")!r})不在末位，卡cot失效')
        print(f'  {sym(CRITICAL)} 预填型 assistant 后还有条目')
    else:
        print(f'  {sym(WARN)} 无预填型 assistant 条目（若需卡cot请添加）')

    # 3.2 输出格式与 content 标签
    fmt_entries = [(o, p) for o, p in enabled
                   if re.search(r'<output_format|输出格式|严格按照以下格式', p.get('content', '') or '')]
    content_open = re.search(r'<content>', json.dumps([p.get('content', '') for _, p in enabled], ensure_ascii=False))
    content_close = re.search(r'</content>', json.dumps([p.get('content', '') for _, p in enabled], ensure_ascii=False))
    if fmt_entries:
        if content_open and content_close:
            print(f'  {sym(OK)} 输出格式含 <content> 完整包裹')
        else:
            problems.append('❌ 输出格式条目未包含 <content>…</content> 完整包裹（注意事项与格式自相矛盾的常见来源）')
            print(f'  {sym(CRITICAL)} 输出格式缺 content 闭合')
    else:
        print(f'  {sym(WARN)} 未找到明确的输出格式条目')

    # 3.3 思考标签一致性：末位 assistant 预填开的标签 vs 思维链定义的标签
    asst_last = meaningful[-1][1] if meaningful and roles[-1] == 'assistant' else None
    if asst_last is not None:
        m = re.findall(r'<([a-zA-Z_][\w~－-]*)>\s*$', (asst_last.get('content', '') or '').rstrip())
        if m:
            tag = m[-1]
            body = json.dumps([p.get('content', '') for _, p in meaningful[:-1]], ensure_ascii=False)
            if f'<{tag}>' in body and f'</{tag}>' in body:
                print(f'  {sym(OK)} 预填开标签 <{tag}> 与思维链定义一致')
            else:
                problems.append(f'❌ 预填开启的 <{tag}> 标签在其他条目中无定义/无闭合')
                print(f'  {sym(CRITICAL)} 预填标签 <{tag}> 无配对定义')
        else:
            print(f'  {sym(WARN)} 末位 assistant 预填不以开标签收尾（可能不适用标签式卡cot）')

    # 3.4 正则检查
    ext = data.get('extensions', {})
    regexes = list(ext.get('regex_scripts') or [])
    sp = ((ext.get('SPreset') or {}).get('RegexBinding') or {}).get('regexes') or []
    all_rx = regexes + sp
    rx_names = list(dict.fromkeys([r.get('scriptName', '?') for r in all_rx]))
    print(f'  正则脚本 {len(rx_names)} 个: ' + (', '.join(rx_names) or '无'))

    def rx_matches_tag(rx_str, tag):
        """判断某条正则是否作用于指定标签字面量（兼容 /pattern/flags 与裸 pattern 两种写法）"""
        s = (rx_str or '').strip()
        m = re.match(r'/(.+)/([a-z]*)$', s)
        pattern = m.group(1) if m else s
        if not pattern:
            return False
        try:
            return re.search(pattern, tag, re.I if 'i' in (m.group(2) if m else '') else 0) is not None
        except re.error:
            return False

    if content_open and not any(rx_matches_tag(r.get('findRegex'), '</content>') for r in all_rx):
        problems.append('⚠️ 正文使用 <content> 标签但无对应的显示隐藏正则')
        print(f'  {sym(WARN)} 缺 <content> 标签隐藏正则')
    has_think_strip = any(re.search(r'think', r.get('findRegex', ''), re.I) and r.get('promptOnly')
                          for r in all_rx)
    if not has_think_strip:
        print(f'  {sym(WARN)} 无 promptOnly 思维链历史剥离正则（旧思维链会持续发送给AI）')

    # 3.5 标记完整性
    markers = {p['identifier'] for p in data.get('prompts', []) if p.get('marker')}
    need = {'chatHistory', 'charDescription', 'personaDescription', 'worldInfoBefore', 'worldInfoAfter'}
    lack = need - markers
    if lack:
        problems.append(f'⚠️ 缺少常用 marker: {lack}')
        print(f'  {sym(WARN)} 缺 marker: {lack}')
    else:
        print(f'  {sym(OK)} 常用 marker 齐全')


def render(prompts, order, show):
    print(c('b', '\n━━━ 4. 宏展开模拟（默认开启条目 → AI 实际收到） ━━━'))
    eng = MacroEngine()
    msgs = []
    for o in order:
        if not o.get('enabled'):
            continue
        p = prompts.get(o['identifier'])
        if not p:
            continue
        if p.get('marker'):
            msgs.append((p.get('role', 'system'), f'[MARKER: {p.get("name")}]'))
            continue
        if p.get('injection_position', 0) == 1:
            continue  # 深度注入不占主流程
        ct = p.get('content', '') or ''
        msgs.append((p.get('role', 'system'), eng.expand(ct).strip()))

    total = sum(len(t) for _, t in msgs)
    print(f'  展开消息 {len(msgs)} 条，正文总量约 {total} 字（≈{total // 2} token 中文粗估）')
    empty = [(i, r) for i, (r, t) in enumerate(msgs) if not t]
    if empty:
        print(f'  {sym(WARN)} 渲染为空的消息 {len(empty)} 条（纯变量/初始化条目属正常）')
    # 重复块检测
    from collections import Counter
    blocks = Counter()
    for _, t in msgs:
        for chunk in re.split(r'\n(?=<)', t):
            if len(chunk.strip()) > 200:
                blocks[chunk.strip()[:80]] += 1
    dups = {k: v for k, v in blocks.items() if v > 1}
    if dups:
        print(f'  {sym(CRITICAL)} 渲染后存在重复块: {list(dups)[:3]}')
    else:
        print(f'  {sym(OK)} 无重复内容块')
    if eng.unresolved:
        from collections import Counter as C2
        u = C2(eng.unresolved)
        print(f'  运行时宏(原样保留，属正常): {dict(list(u.items())[:8])}')
    if show:
        print(c('d', '-' * 60))
        for i, (r, t) in enumerate(msgs):
            if not t:
                continue
            print(f'--- #{i} [{r}] ({len(t)}字) ---')
            print(t)
    return msgs


def main():
    global NO_COLOR
    ap = argparse.ArgumentParser()
    ap.add_argument('preset')
    ap.add_argument('--render', action='store_true', help='输出完整渲染文本')
    ap.add_argument('--no-color', action='store_true')
    args = ap.parse_args()
    NO_COLOR = args.no_color or not sys.stdout.isatty()

    data = load(args.preset)
    if 'prompts' not in data or 'prompt_order' not in data:
        print('不是酒馆预设文件（缺 prompts/prompt_order 字段）')
        sys.exit(2)

    problems = []
    print(c('b', f'===== 预设体检: {args.preset} ====='))
    prompts, order = get_flow(data)
    print(f'条目 {len(data["prompts"])} 个 / order {len(order)} 项')

    check_order_table(prompts, order, problems)
    check_vars(prompts, order, problems)
    check_structure(prompts, order, problems, data)
    render(prompts, order, args.render)

    print(c('b', '\n━━━ 结论 ━━━'))
    crit = [p for p in problems if p.startswith('❌')]
    warn = [p for p in problems if p.startswith('⚠️')]
    for p in problems:
        print(' ', p)
    if not problems:
        print(f'  {sym(OK)} 全部通过')
    print(f'  严重 {len(crit)} / 警告 {len(warn)}')
    sys.exit(1 if crit else 0)


if __name__ == '__main__':
    main()
