# sillytavern-preset

酒馆（SillyTavern）预设工程技能：**从需求一键生成完整预设 / 体检诊断 / 修复**。

任何支持 SKILL.md 格式的 Agent（Trae、Claude Code、Cursor 等）装上即可获得完整的预设工程能力。

## 能力

| 工作流 | 说明 |
|---|---|
| **创建流** | 访谈需求 → 填 spec → `generate_preset.py` 一键生成完整预设（含变量链、转述规则、用户偏好、思维链、卡cot、4条配套正则） |
| **修复流** | `audit_preset.py` 体检 → 按故障对照表修复 → 复检验收 |

体检脚本可检出 12+ 类常见问题：死变量（set 不 get）、幽灵变量（get 不 set）、内容重复发送、addvar 失效、卡cot 错位、输出格式自相矛盾、预填标签断链、思维链历史堆积、正文标签裸露、marker 错乱、token 超载等——并带**宏展开模拟**，直接还原 AI 实际收到的提示词。

沉淀自 V19.5 / 双人成行两个成熟社区预设与社区教程的进阶原理：转述三分法与"转述后决策抢话"、分层指令架构（stage1/stage2）、深度注入就近原则、用户偏好注入区、人物幅度校准（防谄媚/防关系乱升级）、时间校准、MoM 摘要压缩、思维链三步反推法与人格自洽原则——详见 `references/architecture.md`。

## 安装

### Trae

```bash
git clone https://github.com/<你的用户名>/sillytavern-preset.git /data/user/skills/sillytavern-preset
# 或个人目录：~/.trae/skills/sillytavern-preset
```

### Claude Code

```bash
git clone https://github.com/<你的用户名>/sillytavern-preset.git ~/.claude/skills/sillytavern-preset
```

### 其他 Agent

任何扫描 `SKILL.md` 的技能目录都适用：把本仓库克隆进技能目录，保持目录名 `sillytavern-preset` 即可。

## 使用

装好后对 Agent 说：

- 「帮我做一个预设：第二人称、1000字左右、深度思维链」→ 走创建流
- 「我的预设思维链不触发/变量不生效/token爆炸，帮我修」→ 走修复流

### 直接用脚本（无需 Agent）

```bash
# 体检任意预设
python3 assets/audit_preset.py 你的预设.json
python3 assets/audit_preset.py 你的预设.json --render   # 查看AI实际收到的内容

# 从 spec 生成预设
python3 assets/generate_preset.py --init spec.json      # 出模板
# 编辑 spec.json（字段说明见 references/spec.md）
python3 assets/generate_preset.py --spec spec.json --out 我的预设.json
python3 assets/audit_preset.py 我的预设.json            # 验收：应 0 严重问题
```

生成的预设导入酒馆：左上角「AI回复设置」→ 预设管理 → 导入。

## 目录结构

```
├── SKILL.md                    # 技能主文档：双工作流、架构不变式、故障对照表、内容红线
├── assets/
│   ├── generate_preset.py      # 预设生成器（spec → 完整预设）
│   └── audit_preset.py         # 体检脚本（结构+变量链+宏展开模拟）
└── references/
    ├── spec.md                 # 生成 spec 字段全解 + 需求访谈清单
    └── architecture.md         # JSON Schema、marker 清单、标准骨架、宏语义、修复案例
```

## 核心设计（摘要）

1. **开头空变量清零** —— 防旧值残留 token 爆炸
2. **功能条目仅 setvar，汇总点统一 getvar** —— 杜绝内容双倍发送
3. **破限/人格在头部直显** —— 可配 assistant 回信确认身份
4. **卡cot 预填必须是最后一条** —— `<think>` 关原生思考后开自定义思考标签
5. **正文 `<content>` 包裹 + markdownOnly 隐藏正则** —— AI 侧格式一致，人侧干净
6. **生成 → 体检闭环** —— 生成器产物必须通过体检脚本 0 严重问题才算交付

## 内容红线

本技能拒绝构建或修复涉及未成年人性内容的破限组件（如"降低成年年龄线"类设定），发现即移除并说明。生成器默认人格框架为中性虚构续写定位，不主动产出越狱文本；自定义破限内容由使用者自负其责。

## 校准基线

体检脚本在四个真实预设上验证过：时之预设原版检出全部 12 项真实缺陷；修复版全绿；V19.5 / 双人成行两个社区成熟预设仅余合理警告（留档条目、版本迭代遗留的死变量）。
