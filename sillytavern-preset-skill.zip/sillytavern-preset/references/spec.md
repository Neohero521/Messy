# 预设生成 Spec 参考

`generate_preset.py` 以 spec JSON 为蓝图生成完整预设。Agent 的职责：**问清需求 → 填 spec → 生成 → 体检**。

```bash
python3 assets/generate_preset.py --init spec.json   # 写出模板
# 编辑 spec.json 后：
python3 assets/generate_preset.py --spec spec.json --out 预设名.json
python3 assets/audit_preset.py 预设名.json           # 必须 0 严重问题
```

## 需求访谈清单（用户说"随便"就全用默认）

| 问题 | spec 字段 | 默认 |
|---|---|---|
| 预设叫什么名字？ | `preset_name` | 我的预设 |
| 想要什么人格/风格？（神/作家/馆长…） | `persona.name` | 叙事者 |
| 有自己的破限/人格文本吗？ | `persona.frame_text` | 空→用内置中性虚构续写框架 |
| 用第几人称视角？ | `pov` | second |
| 每轮正文字数？ | `word_count` | 700–1000 |
| 思维链要多细？ | `thinking_chain.mode` | standard |
| 用户输入怎么处理？（转述方式） | `paraphrase` | segmented |
| 有没有固定口味/雷区要写进预设？ | `user_prefs` | 空 |
| 要哪些防套路功能？ | `features.*` | 防全知+禁抢话 |
| 有自定义文风吗？ | `style.text` | 空 |
| 要摘要功能吗？ | `summary.enabled` | false |

## 字段全解

### 顶层

```jsonc
{
  "preset_name": "我的预设",          // 输出文件名与展示名
  "output_language": "简体中文",       // 任意语言名
  "word_count": { "min": 700, "max": 1000, "enabled": true },
  "persona": { ... },                // 见下
  "pov": "second",                   // first-user | second | third
  "paraphrase": "segmented",         // segmented | direct | none（转述方式，见下）
  "user_prefs": "",                  // 用户偏好文本（基调/雷区/文风偏好等，见下）
  "features": { ... },               // 见下
  "style": { ... },                  // 见下
  "thinking_chain": { "enabled": true, "mode": "standard" },
  "summary": { "enabled": false },
  "anchor": true,                    // 尾部锚定条目
  "cot_hijack": true                 // 末位 assistant 预填（卡cot）
}
```

### paraphrase（转述规则，源自 V19.5 原理）

控制 AI 如何处理用户**已写出**的输入（与"抢话"——替用户写新内容——是两回事）：

| 值 | 行为 | 适用 |
|---|---|---|
| `segmented` | 分段转述：先判断输入类型——RP输入融入正文（对白原话保留）；指令输入只推动剧情、不改写成用户台词 | 通用推荐（默认） |
| `direct` | 直接转述：正文开头完整融入用户输入，拒绝间接引语概括 | 用户输入简短、要承接感 |
| `none` | 禁止转述：用户消息已是故事一部分，从停下处直接续写 | 用户长文写作、复读严重时 |

生成的预设会在 PHI 汇总点装配转述规则 + "转述 vs 抢话"区分口诀（能否抢话是转述后的决策），思维链的用户输入处理环节会对照检查。

### user_prefs（用户偏好）

固定口味写进预设，每轮生效：文本原样包进 `<User_Prefs>` 区块注入在 PHI 之前，思维链设对照检查。示例：

```json
"user_prefs": "故事基调偏好：暗黑悬疑；雷区：不写宠物死亡、不写NTR；互动风格：慢热克制"
```

进阶玩法：留空此字段，在酒馆里把世界书蓝灯条目插到"🧭 用户偏好"位置，实现按剧情动态触发（V19.5 模式）。

### persona（人格/破限）

```jsonc
{
  "name": "叙事者",                  // 人格代号，注入框架与回信
  "frame_text": "",                  // 自定义人格框架/破限文本；空则用内置中性框架
  "enable_reply": true,              // 是否生成 assistant 角色回信（人格确认）
  "assistant_reply": ""              // 自定义回信文本；空则用内置模板
}
```

**红线**：`frame_text` 由用户提供时，Agent 必须审查——涉及未成年人性内容的破限文本（降低成年年龄线、under-18 协议等）**拒绝写入并移除**，向用户说明。成人向内容由用户自负其责，Agent 不主动编写或增强越狱文本。

### features（功能开关）

```jsonc
{
  "no_user_action": true,        // 禁止抢话（默认开）
  "slight_user_action": false,   // 微量抢话·仅替用户说话（备用条目，默认关）
  "anti_omniscience": true,      // 角色防全知（默认开）
  "anti_sublimation": false,     // 抗升华（禁总结式结尾/哲理旁白）
  "anti_cliche": false,          // 防八股（禁模板句式/劣质比喻）
  "ooc_lock": false,             // OOC 锁定（备用条目，默认关）
  "thinking_intensity": false,   // 思考强度·穷尽模式（备用条目，默认关）
  "char_calibration": false      // 人物幅度校准（防谄媚/防关系乱升级/防倒推便利事实）
}
```

`no_user_action` 与 `slight_user_action` 互斥；后者生成的是默认关闭的备用条目，用户可在酒馆里自行切换。

`char_calibration`（源自 13(1) 的 Gemini/GLM 校准精要，对所有模型通用）：反应幅度匹配刺激、高影响事实必须有来源、不先定结果再倒推便利事实、不反复盖章同义标签、普通协作不自动升级为特殊感情、结尾不总结关系不宣告成长。

### style（文风）

```jsonc
{ "text": "", "include_light_novel": false }
```

- `text`：自定义文风描述 → 生成"✒️ 自定义文风"条目（setvar style_custom，PHI 装配）
- `include_light_novel`：附加"📝 日式轻小说文风"备用条目（默认关）

### thinking_chain（思维链）

| mode | 名称 | 内容 | 适用 |
|---|---|---|---|
| `lite` | 精简 | 速查五问 | 快节奏聊天、省 token |
| `standard` | 标准 | 盘点/边界/叙事/输入处理/自查 | 通用推荐 |
| `deep` | 深度 | 感知边界+内心预演+导演检查+反套路推翻+硬规则 | 长篇严肃创作 |

`enabled: false` 则完全不生成思维链条目（卡cot 预填引用会失效，此时建议同时关 `cot_hijack`）。

### summary（摘要）

`enabled: true` 时生成"📝 摘要（总结）"条目（默认关闭，用户在酒馆里手动开启）。格式为 `<details>` 折叠块，酒馆原生渲染无需额外正则。配合 MoM 类"n 楼外只发摘要"正则可做记忆压缩。

## 生成的预设结构

```
⚙️ 变量初始化（勿关）→ 🌐 输出语言 → 📏 字数控制
→ 🎭 人格框架 → 🎭 人格确认(AI回信)
→ 功能带(抢话/防全知/抗升华/防八股/OOC/思考强度/人物幅度校准) → 视角 → 转述 → 文风
→ Main Prompt → [世界书/人设/角色卡/场景 marker 组] → 聊天记录包裹
→ 🧭 用户偏好(可选) → Post-History Instructions(PHI 装配: 核心规则+转述+视角+防套路+文风)
→ 💭 思维链 → 📝 摘要 → 🎯 输出格式 → 🌕 尾部锚定 → 🐍 卡cot(assistant 末位预填)
```

自带 4 条正则：思维链美化（显示）、去除原生思维链（显示）、思维链历史剥离（仅发送侧）、正文标签隐藏（仅显示侧）。

## 最小可运行示例

```json
{
  "preset_name": "轻聊预设",
  "pov": "second",
  "thinking_chain": { "enabled": true, "mode": "lite" },
  "features": { "no_user_action": true, "anti_omniscience": true }
}
```

未填字段全部回落默认值。
