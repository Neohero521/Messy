---
name: sillytavern-preset
description: Create, generate, audit, and repair SillyTavern chat completion presets (酒馆预设). Use when users want to build or generate a preset from requirements (从零生成预设/做预设/写预设), fix a broken preset, or diagnose issues like dead setvar/getvar variable chains (变量断链), duplicated prompt content (重复输出), broken thinking chains (思维链断裂), failed CoT hijack (卡cot失效), wrong prompt ordering, output format problems (输出格式), missing regex (正则缺失), or token bloat. Covers spec-driven generation, preset JSON schema, variable architecture, prompt ordering, and macro-render verification. 预设生成/创建/体检/修复一站式技能。
---

# SillyTavern 预设工程（生成 / 体检 / 修复）

为酒馆（SillyTavern）对话补全预设提供从需求到成品的完整能力：**spec 驱动生成、体检诊断、修复**。核心方法论：**对照成熟架构不变式 + 宏展开模拟验证**。

## 何时使用

- 用户想从零得到一个预设（"帮我写个预设""做个XX风格的预设"）→ 走【创建流】
- 用户已有预设出问题（空回、降智、格式乱、变量不生效、思维链不触发、抢话、token 爆炸）→ 走【修复流】
- 用户想二改/缝合预设，或想知道预设为什么这么排 → 走【修复流】
- 用户上传 `.json` 且包含 `prompts` + `prompt_order` 字段（酒馆预设特征）

## 创建流：从需求到预设（5 步）

1. **访谈**：按 `references/spec.md` 的清单问需求（名字/人格/视角/字数/转述方式/用户口味雷区/思维链档位/功能开关/文风/摘要）。用户说"随便"就全用默认值，不要追问
2. **写 spec**：把答案填成 spec JSON（可直接 `--init` 生成模板再改）
3. **生成**：`python3 <skill_dir>/assets/generate_preset.py --spec spec.json --out 预设名.json`
4. **验收**：`python3 <skill_dir>/assets/audit_preset.py 预设名.json` —— 必须 **0 严重问题**；加 `--render` 目检 AI 实际收到的内容
5. **交付**：附使用说明（导入方法、各开关建议、测试方法：先随便聊几楼，再只开可疑条目聊几楼）

人格/破限文本由用户提供时（spec.persona.frame_text）必须过红线审查（见下）；默认内置的是中性虚构续写框架。

## 修复流：体检 → 修复 → 复检

1. **体检**：`python3 <skill_dir>/assets/audit_preset.py <预设.json>`
   输出条目顺序表、变量链审计、结构检查、宏展开渲染统计与问题清单（❌严重 / ⚠️警告 / ✓通过）
2. **修复**：按下方"故障对照表"逐项处理，改 JSON（保持字段结构，勿动无关设置）
3. **复检**：重跑体检脚本确认 ❌ 清零；加 `--render` 目检 AI 实际收到的完整提示词
4. **交付**：保存为新文件（勿覆盖原件），提醒用户实测——先随便聊几楼，再只开可疑条目聊几楼定位问题

## 架构不变式（金科玉律）

对照两个经过验证的社区预设（V19.5、13(1)）提炼，任何预设都应满足：

1. **开头空变量清零**：第一个条目（常驻开启）把所有变量 `{{setvar::X::}}` 置空，防止旧值残留导致 token 爆炸
2. **功能条目仅 setvar，汇总点统一 getvar**：`{{setvar::X::内容}}` 只存储不显示；在使用位置（通常是聊天记录后的汇总条目）`{{getvar::X}}` 装配。**严禁**条目内 set+get 且别处又 get（内容双倍发送）
3. **破限放开头**：破限/人格化条目在头部直接显示（不用变量），常配一条 assistant 角色回信让 AI 认可身份
4. **卡 cot 的 assistant 预填必须是最后一条**：`<think>…</think>` 关原生思考 → 开自定义思考标签收尾。它后面不能再有任何条目，否则预填失效
5. **正文用 `<content>` 包裹**：输出格式条目必须包含 `<content>正文</content>` 完整闭合，并配"仅改显示"的隐藏正则（`markdownOnly: true`，AI 历史中保留标签维持格式一致）
6. **每个板块用 XML 标签包裹**：思维链 `<thinking>`、输出契约 `<output_format>`、行为约束 `<style_rules>` 等，方便思维链 call back（"遵循 \<xxx\> 中的要求"）
7. **token 预算**：空卡纯预设建议控制在 8k–1w token；超过即需要摘要功能（`recap` 类变量 + 楼层外只发摘要的正则）
8. **指令分层与就近原则**：语境建立型规则放聊天记录前（stage1），本轮必须遵守的约束放聊天记录后（PHI/stage2）；越需要严格遵守的规则越靠近输出端（必要时用深度注入 INJ@0~2）
9. **转述与抢话分离**：转述处理用户已写出的内容，抢话是替用户写新内容；能否抢话必须是"转述之后"的决策——两者混为一谈是复读/抢话类 bug 的共同根因

## 故障对照表

| 症状/检测项 | 根因 | 修复 |
|---|---|---|
| setvar 了但 AI 读不到 | 死变量：从未 getvar | 在正确汇总点补 getvar，或改为就地显示 |
| getvar 渲染永远为空 | 幽灵变量：只 get 从未 set（常见于宏被 str.format 转义成单花括号） | 补 setvar 生产条目；改用 `<<token>>`+replace 填充，禁用 .format() |
| 内容重复发送、token 翻倍 | 条目内 set+get 且汇总点又 get | 条目只留 setvar（或改直显），删除其一 |
| addvar 不生效 | 前面没有 setvar 初始化 | 开头清零条目补 `{{setvar::X::}}` |
| 卡 cot 无效、思维链乱跑 | assistant 预填不在末尾 | 把它移到 prompt_order 最后 |
| AI 复读用户输入、不推进 | 转述规则缺失或误用"不要转述" | 按 V19.5 三分法补转述规则（分段/直接/禁止），见 references/architecture.md §11 |
| AI 替用户做决定（抢话） | 转述与抢话混淆——能否抢话应是"转述后"的决策 | PHI 装配点加"转述 vs 抢话"区分口诀 + 抢话规则 |
| AI 无视用户口味/踩雷区 | 缺用户偏好注入区 | 加 `<User_Prefs>` 注入条目 + 思维链对照检查 |
| 人物太谄媚、关系乱升级、剧情倒推便利事实 | 缺人物幅度校准 | 加校准规则块（见 architecture.md §15） |
| 规则总是不被遵守 | 规则离输出端太远 | 移到 PHI（stage2）或改深度注入（INJ@0~2），越严格越靠近输出端 |
| 长篇时间线混乱 | 缺时间校准 | 思维链加内部时钟环节（architecture.md §16） |
| AI 不按格式输出正文 | 输出格式缺 `<content>` 闭合 / 条目间标签引用不一致 | 修输出格式条目，统一思考/正文标签 |
| 预填引用了不存在的标记 | 拆条目时留下断头残片（如 `[metacognition]`、孤立闭标签） | 删除残片，规则并入完整条目 |
| 聊天记录里 AI 看到旧思维链 | 缺 promptOnly 清除正则 | 加 `<thinking>…</thinking>` 发送时剥离正则 |
| 正文书名号标签裸露在界面上 | 缺显示隐藏正则 | 加 `/<\/?content>/g` → 空，markdownOnly |
| 世界书/人设位置混乱 | marker 条目顺序错乱 | 按 人设→角色定义前后→场景→对话示例→聊天记录 排布 |
| 模型降智 | 纯预设 token 超 1w | 精简条目 + 启用摘要压缩 |

## 变量系统规则（速记）

- `{{setvar::名::内容}}` 存值（同 名 覆盖）；`{{addvar::名::内容}}` 追加（需先有 setvar）；`{{getvar::名}}` 取值显示；`{{getvar::名::默认}}` 支持默认值；`{{random::a::b::c}}` 随机取一（防 429）
- 没被 getvar 的 setvar 在 AI 眼里是空白
- 双花括号必须完整；setvar/addvar 即使空值也必须保留双冒号

## 消息角色技巧

- `system`：常规指令
- `user` + 伪造 assistant JSON：Claude 系卡 cot 变体
- `assistant`：回信（破限人格确认）、末位预填（卡 cot）
- `injection_position: 1` + `injection_depth: N`：深度注入（插进聊天记录第 N 层），不占主流程顺序

## 内容红线（必须遵守）

- **涉及未成年人的性内容破限组件**（如"降低成年年龄线""juvenile/under-18 内容无限制协议"类条目）：**拒绝构建、拒绝修复、直接移除**，并向用户明确说明原因。发现即清除，无例外
- 不主动编写或增强越狱/破限文本；只做结构修复与既有成人向内容的原样保留
- 修复后必须完整告知用户改了什么、为什么改

## 参考文件

- `references/spec.md` — 生成 spec 字段全解、需求访谈清单、最小示例
- `references/architecture.md` — 预设 JSON 完整 schema、marker 标识符清单、推荐条目骨架、宏清单、正则结构、时之预设修复案例
- `assets/generate_preset.py` — 预设生成器（spec → 完整预设，含模块库与 4 条配套正则）
- `assets/audit_preset.py` — 体检脚本（结构 + 变量链 + 宏展开模拟）
